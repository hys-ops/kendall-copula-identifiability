import KendallCut
import KendallRigidity

noncomputable section
open Set MeasureTheory Filter
namespace KendallMeasureRigidity

abbrev rank := Ioo (0:ℝ) 1
abbrev rankPrefix (p : ℝ) := Ioo (0:ℝ) p

/-- Local conditions for a bounded rank-space harmonic function with
a kernel uniformly positive on pairs separated in profile value. -/
structure Rows (μ : Measure ℝ) (z : ℝ → ℝ) (H : ℝ → ℝ → ℝ) (B : ℝ) : Prop where
  Bpos : 0<B
  measurable : Measurable z
  bounded : ∀ p ∈ rank, z p ∈ Icc (0:ℝ) 1
  finite : ∀ p ∈ rank, μ (rankPrefix p) ≠ ⊤
  positive : ∀ p ∈ rank, 0 < μ.real (rankPrefix p)
  rowBound : ∀ p ∈ rank, ∀ s ∈ rankPrefix p, H p s ∈ Icc (0:ℝ) B
  separated : ∀ γ > 0, ∃ α > 0, ∀ p ∈ rank, ∀ s ∈ rankPrefix p, γ ≤ |z p-z s| → α ≤ H p s
  hInt : ∀ p ∈ rank, IntegrableOn (H p) (rankPrefix p) μ
  zhInt : ∀ p ∈ rank, IntegrableOn (fun s => z s*H p s) (rankPrefix p) μ
  harmonic : ∀ p ∈ rank, (∫ s in rankPrefix p, (z p-z s)*H p s ∂μ) = 0

theorem Rows.reflect {μ z H B} (R : Rows μ z H B) : Rows μ (fun s => 1-z s) H B where
  Bpos := R.Bpos
  measurable := measurable_const.sub R.measurable
  bounded p hp := ⟨sub_nonneg.mpr (R.bounded p hp).2, sub_le_self _ (R.bounded p hp).1⟩
  finite := R.finite
  positive := R.positive
  rowBound := R.rowBound
  separated γ hγ := by
    obtain ⟨α,hα,hh⟩ := R.separated γ hγ
    refine ⟨α,hα,fun p hp s hs h => hh p hp s hs ?_⟩
    convert h using 1
    rw [show 1-z p-(1-z s) = z s-z p by ring,abs_sub_comm]
  hInt := R.hInt
  zhInt p hp := by
    have he : (fun s => (1-z s)*H p s) = (fun s => H p s) - (fun s => z s*H p s) := by
      funext s; dsimp; ring
    rw [he]
    exact (R.hInt p hp).sub (R.zhInt p hp)
  harmonic p hp := by
    have he (s : ℝ) : (1-z p-(1-z s))*H p s = -((z p-z s)*H p s) := by ring
    simp only [he, integral_neg, R.harmonic p hp,neg_zero]

theorem restrict_real {μ : Measure ℝ} {T S : Set ℝ} (hs : MeasurableSet S) (hst : S ⊆ T) :
    (μ.restrict T).real S = μ.real S := by
  simp [Measure.real,Measure.restrict_apply hs,inter_eq_left.mpr hst]
theorem restrict_real_univ (μ : Measure ℝ) (T : Set ℝ) :
    (μ.restrict T).real univ = μ.real T := by simp [Measure.real]

end KendallMeasureRigidity
