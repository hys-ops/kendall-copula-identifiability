import Mathlib.Basic.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! Quantitative constants converting prefix integral bounds to the barrier. -/
namespace KendallBudget

theorem small_bad {D α B : ℝ} (hD : 0 < D) (ha : 0 < α) (hB : 0 < B) :
    ∃ η > 0, η ≤ D/2 ∧ ∀ {gap bad mass : ℝ}, 0 ≤ gap → gap < η →
      0 ≤ bad → 0 < mass → (D*α)*bad ≤ gap*B*mass →
      (B+D*α)*bad ≤ (D*α/2)*mass := by
  let k := D*α
  have hk : 0 < k := mul_pos hD ha
  have hsum : 0 < B+k := add_pos hB hk
  let η := min (D/2) (((k/2)*k)/(B+k)/B)
  refine ⟨η, lt_min (by positivity) (by positivity), min_le_left _ _, ?_⟩
  intro gap bad mass _ hgap _ hm hin
  have hc : gap ≤ (((k/2)*k)/(B+k)/B) :=
    hgap.le.trans (min_le_right _ _)
  have hx := (le_div_iff₀ hB).mp hc
  have hy := (le_div_iff₀ hsum).mp hx
  change (B+k)*bad ≤ (k/2)*mass
  apply (mul_le_mul_iff_left₀ hk).mp
  calc
    ((B+k)*bad)*k = (B+k)*(k*bad) := by ring
    _ ≤ (B+k)*(gap*B*mass) := mul_le_mul_of_nonneg_left hin hsum.le
    _ = (gap*B*(B+k))*mass := by ring
    _ ≤ ((k/2)*k)*mass := mul_le_mul_of_nonneg_right hy hm.le
    _ = ((k/2)*mass)*k := by ring

theorem repel {D α B mass total : ℝ}
    (hD : 0 < D) (ha : 0 < α) (hB : 0 < B) (hm : 0 < mass) (ht : 0 < total) :
    ∃ ε > 0, ∀ {bad good totalq gap : ℝ}, mass ≤ bad+good → 0 ≤ gap →
      totalq ≤ total → (B+D*α)*bad ≤ (D*α/2)*mass →
      (D*α)*good ≤ B*bad+gap*B*totalq → ε ≤ gap := by
  let k := D*α
  have hk : 0 < k := mul_pos hD ha
  refine ⟨(k/2*mass)/(B*total), by positivity, ?_⟩
  intro bad good totalq gap hrow hg hq hb hlow
  have hadd := mul_le_mul_of_nonneg_left hrow hk.le
  have hq' := mul_le_mul_of_nonneg_left hq (mul_nonneg hg hB.le)
  apply (div_le_iff₀ (mul_pos hB ht)).mpr
  change (B+k)*bad ≤ (k/2)*mass at hb
  change k*good ≤ _ at hlow
  nlinarith

end KendallBudget
#print axioms KendallBudget.small_bad
#print axioms KendallBudget.repel
