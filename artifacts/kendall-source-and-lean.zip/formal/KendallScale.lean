import KendallRank
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Topology.NhdsWithin
import Mathlib.Topology.Order.DenselyOrdered
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! Consequences of a constant projective coordinate for arbitrary finite dimensions. -/
noncomputable section
open Set MeasureTheory
open scoped BigOperators
namespace KendallScale

/-- The generator obtained from a positive reciprocal-radius quantile. -/
def generator (m : ℕ) (x : ℝ → ℝ) (r : ℝ) : ℝ :=
  ∫ s in Ioo (0:ℝ) 1, (max (1-r*x s) 0)^m

/-- A constant normalized comparison gives proportional quantiles. -/
theorem proportional {x y : ℝ → ℝ}
    (hx : ∀ p ∈ Ioo (0:ℝ) 1, 0 < x p) (hy : ∀ p ∈ Ioo (0:ℝ) 1, 0 < y p)
    (h : ∃ a : ℝ, ∀ p ∈ Ioo (0:ℝ) 1, x p/(x p+y p)=a) :
    ∃ c > 0, ∀ p ∈ Ioo (0:ℝ) 1, y p=c*x p := by
  obtain ⟨a,ha⟩ := h
  have hm : (1/2:ℝ) ∈ Ioo 0 1 := by constructor <;> norm_num
  refine ⟨y (1/2)/x (1/2), div_pos (hy _ hm) (hx _ hm), ?_⟩
  intro p hp
  have he := (ha p hp).trans (ha _ hm).symm
  have he' := (div_eq_div_iff (add_pos (hx p hp) (hy p hp)).ne'
    (add_pos (hx _ hm) (hy _ hm)).ne').mp he
  rw [div_mul_eq_mul_div]
  apply (eq_div_iff (hx _ hm).ne').mpr
  nlinarith

/-- Positive scaling of quantiles rescales the generator argument. -/
theorem generator_rescale (m : ℕ) {x y : ℝ → ℝ} {c : ℝ}
    (h : ∀ p ∈ Ioo (0:ℝ) 1, y p=c*x p) (r : ℝ) :
    generator m y r = generator m x (c*r) := by
  unfold generator
  apply setIntegral_congr_fun measurableSet_Ioo
  intro p hp
  dsimp only
  rw [h p hp]
  congr 3
  ring

abbrev cube (d : ℕ) := (univ : Set (Fin d)).pi (fun _ => Icc (0:ℝ) 1)
abbrev interiorCube (d : ℕ) := (univ : Set (Fin d)).pi (fun _ => Ioo (0:ℝ) 1)

/-- Only the ordinary Archimedean CDF and the inverse on positive levels
are needed to recover the CDF, including faces where inverse radii may diverge. -/
structure Represents (d : ℕ) (C : (Fin d → ℝ) → ℝ) (ψ φ : ℝ → ℝ) : Prop where
  continuousOn : ContinuousOn C (cube d)
  interior : ∀ u ∈ interiorCube d, C u = ψ (∑ i, φ (u i))
  positive : ∀ u ∈ Ioo (0:ℝ) 1, 0 < φ u
  eval_inv : ∀ u ∈ Ioo (0:ℝ) 1, ψ (φ u) = u
  inv_eval : ∀ t > 0, ψ t ∈ Ioo (0:ℝ) 1 → φ (ψ t) = t

theorem copula_eq_of_proportional {d : ℕ} {x y φ₁ φ₂ : ℝ → ℝ} {C₁ C₂ : (Fin d → ℝ) → ℝ}
    (h₁ : Represents d C₁ (generator (d-1) x) φ₁)
    (h₂ : Represents d C₂ (generator (d-1) y) φ₂)
    {c : ℝ} (hc : 0 < c) (hscale : ∀ p ∈ Ioo (0:ℝ) 1, y p=c*x p) :
    EqOn C₁ C₂ (cube d) := by
  have hφ : ∀ u ∈ Ioo (0:ℝ) 1, φ₁ u = c * φ₂ u := by
    intro u hu
    have he : generator (d-1) x (c*(φ₂ u)) = u :=
      (generator_rescale (d-1) hscale (φ₂ u)).symm.trans (h₂.eval_inv u hu)
    have hh := h₁.inv_eval (c*(φ₂ u)) (mul_pos hc (h₂.positive u hu)) (by rw [he]; exact hu)
    rwa [he] at hh
  have hi : EqOn C₁ C₂ (interiorCube d) := by
    intro u hu
    rw [h₁.interior u hu,h₂.interior u hu,generator_rescale (d-1) hscale,Finset.mul_sum]
    exact congrArg (generator (d-1) x) (Finset.sum_congr rfl fun i _ => hφ _ (hu i (mem_univ i)))
  apply hi.of_subset_closure h₁.continuousOn h₂.continuousOn
  · intro u hu i h
    exact Ioo_subset_Icc_self (hu i h)
  · unfold cube interiorCube
    rw [closure_pi_set]
    simp only [closure_Ioo (show (0:ℝ) ≠ 1 by norm_num), subset_refl]

end KendallScale
#print axioms KendallScale.copula_eq_of_proportional
