import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Linarith

/-! Deterministic near-extremum selection on ordered rank intervals. Neither
continuity of the profile nor attainment of the extrema is required. -/
open Set
namespace KendallRigidity

/-- Local quantitative form proved from the integral estimates: if the profile
at b is below a comparison level M, a point close enough to M forces a
strictly positive gap above any putative lower bound m on the remaining interval. -/
def Barrier (z : ℝ → ℝ) (b : ℝ) : Prop :=
  ∀ M δ : ℝ, 0 < δ → z b + 3*δ < M →
    (∀ p ∈ Ioc (0:ℝ) b, z p ≤ M) →
    ∃ η > 0, ∀ a ∈ Ioc (0:ℝ) b, M-z a < η →
      ∀ m : ℝ, 0 ≤ m → m ≤ z b → (∀ p ∈ Icc a b, m ≤ z p) →
      ∃ ε > 0, ∀ p ∈ Icc a b, z p < m+δ → m+ε ≤ z p

/-- The deterministic maximum principle on a single prefix. -/
theorem prefix_max {z : ℝ → ℝ} {b : ℝ} (hb : 0 < b)
    (hz : ∀ p ∈ Ioc (0:ℝ) b, z p ∈ Icc (0:ℝ) 1)
    (hbar : Barrier z b) : ∀ p ∈ Ioc (0:ℝ) b, z p ≤ z b := by
  let S := z '' Ioc (0:ℝ) b
  have hbb : b ∈ Ioc (0:ℝ) b := ⟨hb,le_rfl⟩
  have hne : S.Nonempty := ⟨z b,b,hbb,rfl⟩
  have hbound : BddAbove S := ⟨1,by rintro _ ⟨p,hp,rfl⟩; exact (hz _ hp).2⟩
  let M := sSup S
  have hM : ∀ p ∈ Ioc (0:ℝ) b, z p ≤ M := fun p hp => le_csSup hbound ⟨p,hp,rfl⟩
  suffices hh : M ≤ z b from fun p hp => (hM p hp).trans hh
  by_contra! hgap
  let δ := (M-z b)/4
  have hδ : 0 < δ := by dsimp [δ]; linarith
  obtain ⟨η,hη,peak⟩ := hbar M δ hδ (by dsimp [δ]; linarith) hM
  obtain ⟨_,⟨a,ha,rfl⟩,ha'⟩ := exists_lt_of_lt_csSup hne (show M-η<M by linarith)
  let T := z '' Icc a b
  have hb' : b ∈ Icc a b := ⟨ha.2,le_rfl⟩
  have hne' : T.Nonempty := ⟨z b,b,hb',rfl⟩
  have hm' : ∀ p ∈ Icc a b, z p ∈ Icc (0:ℝ) 1 := fun p hp => hz p ⟨ha.1.trans_le hp.1,hp.2⟩
  have hbounded : BddBelow T := ⟨0,by rintro _ ⟨p,hp,rfl⟩; exact (hm' _ hp).1⟩
  let m := sInf T
  have hm : ∀ p ∈ Icc a b, m ≤ z p := fun p hp => csInf_le hbounded ⟨p,hp,rfl⟩
  have hm0 : 0 ≤ m := le_csInf hne' (by rintro _ ⟨p,hp,rfl⟩; exact (hm' _ hp).1)
  obtain ⟨ε,hε,hmin⟩ := peak _ ha (by linarith) m hm0 (hm b hb') hm
  obtain ⟨_,⟨p,hp,rfl⟩,hp'⟩ := exists_lt_of_csInf_lt hne'
    (show m<m+min ε δ by linarith [lt_min hε hδ])
  have h₁ : z p < m+δ := by linarith [min_le_right ε δ]
  have h₂ := hmin p hp h₁
  linarith [min_le_left ε δ]

/-- A profile and its reflected profile satisfying the maximum principle are
constant, independently of jumps or plateaus. -/
theorem constant_of_barriers {z : ℝ → ℝ}
    (hz : ∀ p ∈ Ioo (0:ℝ) 1, z p ∈ Icc (0:ℝ) 1)
    (hbar : ∀ b ∈ Ioo (0:ℝ) 1, Barrier z b)
    (href : ∀ b ∈ Ioo (0:ℝ) 1, Barrier (fun p => 1-z p) b) :
    ∃ c : ℝ, ∀ p ∈ Ioo (0:ℝ) 1, z p = c := by
  have same {a b : ℝ} (ha : a ∈ Ioo 0 1) (hb : b ∈ Ioo 0 1) (hab : a ≤ b) : z a = z b := by
    have hbound : ∀ p ∈ Ioc (0:ℝ) b, z p ∈ Icc (0:ℝ) 1 :=
      fun _ hp => hz _ ⟨hp.1,hp.2.trans_lt hb.2⟩
    have hbound' : ∀ p ∈ Ioc (0:ℝ) b, (fun u => 1-z u) p ∈ Icc (0:ℝ) 1 := by
      intro p hp
      exact ⟨sub_nonneg.mpr (hbound _ hp).2,sub_le_self _ (hbound _ hp).1⟩
    have h₁ := prefix_max hb.1 hbound (hbar b hb) a ⟨ha.1,hab⟩
    have h₂ := prefix_max hb.1 hbound' (href b hb) a ⟨ha.1,hab⟩
    linarith
  have hc : (1/2:ℝ) ∈ Ioo 0 1 := by constructor <;> norm_num
  refine ⟨z (1/2),fun p hp => ?_⟩
  rcases le_total p (1/2) with h | h
  · exact same hp hc h
  · exact (same hc hp h).symm

end KendallRigidity
