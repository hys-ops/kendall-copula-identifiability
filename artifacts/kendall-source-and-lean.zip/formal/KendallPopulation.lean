import KendallQuantile
import KendallTheorem

/-! Population identification in the classical Williamson representation,
without a given quantile or regularity of either positive radial law. -/
noncomputable section
open Set MeasureTheory
namespace KendallPopulation

/-- Williamson generator from a positive reciprocal-radius probability law. -/
def generator (μ : Measure ℝ) (m : ℕ) (r : ℝ) : ℝ :=
  ∫ t, max (1-r*t) 0 ^ m ∂μ

theorem generator_quantile (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Iic 0) = 0) (m : ℕ) :
    KendallScale.generator m (KendallRank.quantileOfMeasure μ hμ).x = generator μ m := by
  funext r
  unfold generator
  conv_rhs => rw [← KendallRank.quantileOfMeasure_map μ hμ]
  symm
  apply integral_map_of_stronglyMeasurable (KendallRank.quantileOfMeasure μ hμ).measurable
  fun_prop

/-- For every finite d≥2, equality in distribution of the Williamson scores of
the original radial variables identifies the copula everywhere on the closed unit cube. -/
theorem identifies {d : ℕ} (hd : 2 ≤ d) (μ ν : Measure ℝ)
    [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hμ : μ (Iic 0) = 0) (hν : ν (Iic 0) = 0)
    {φ₁ φ₂ : ℝ → ℝ} {C₁ C₂ : (Fin d → ℝ) → ℝ}
    (h₁ : KendallScale.Represents d C₁ (generator μ (d-1)) φ₁)
    (h₂ : KendallScale.Represents d C₂ (generator ν (d-1)) φ₂)
    (hlaw : KendallRank.radialKendallLaw μ (d-1) = KendallRank.radialKendallLaw ν (d-1)) :
    EqOn C₁ C₂ (KendallScale.cube d) := by
  apply KendallTheorem.identifies hd (KendallRank.quantileOfMeasure μ hμ)
    (KendallRank.quantileOfMeasure ν hν)
  · rwa [generator_quantile]
  · rwa [generator_quantile]
  · simpa only [KendallRank.kendallLaw_quantileOfMeasure] using hlaw

end KendallPopulation
#print axioms KendallPopulation.identifies
