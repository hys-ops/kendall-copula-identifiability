import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity

/-! Quantitative comparison of the rank harmonic kernel with its reference measure. -/
noncomputable section
open Set Filter MeasureTheory
namespace KendallHarmonicLocal

/-- The displacement of normalized positive coordinates is controlled by the larger
relative decrease of the two separate coordinates. -/
theorem coordinate_separation {a b A B : ℝ} (ha : 0 < a) (hb : 0 < b)
    (hA : a ≤ A) (hB : b ≤ B) :
    |a/(a+b) - A/(A+B)| ≤ max (1-a/A) (1-b/B) := by
  have hAp := ha.trans_le hA
  have hBp := hb.trans_le hB
  have hab : 0 < a+b := add_pos ha hb
  have hAB : 0 < A+B := add_pos hAp hBp
  have hs : a+b ≤ A+B := add_le_add hA hB
  have aux {u v U V : ℝ} (hu : 0 < u) (hv : 0 < v) (hU : u ≤ U) (hV : v ≤ V) :
      U/(U+V)-u/(u+v) ≤ 1-u/U := by
    have hm := div_le_div_of_nonneg_left hu.le (add_pos hu hv) (add_le_add hU hV)
    have hUU := hu.trans_le hU
    have hVV := hv.trans_le hV
    calc
      U/(U+V)-u/(u+v) ≤ U/(U+V)-u/(U+V) := by linarith
      _ = (U-u)/(U+V) := (sub_div ..).symm
      _ ≤ (U-u)/U := div_le_div_of_nonneg_left (sub_nonneg.mpr hU) hUU (le_add_of_nonneg_right hVV.le)
      _ = 1-u/U := by rw [sub_div, div_self hUU.ne']
  apply abs_sub_le_iff.mpr
  constructor
  · have hh := aux hb ha hB hA
    have heq : a/(a+b) - A/(A+B) = B/(B+A) - b/(b+a) := by
      field_simp
      ring
    rw [heq]
    exact hh.trans (le_max_right _ _)
  · exact (aux ha hb hA hB).trans (le_max_left _ _)

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsFiniteMeasure μ]

/-- A nonnegative integral controls every set on which its integrand is bounded below. -/
theorem mass_control {g : Ω → ℝ} {S : Set Ω} {q : ℝ} (hS : MeasurableSet S)
    (hg : Integrable g μ) (hgn : 0 ≤ᵐ[μ] g) (h : ∀ᵐ ω ∂μ, ω ∈ S → q ≤ g ω) :
    q * μ.real S ≤ ∫ ω, g ω ∂μ := by
  have hi := (integrable_const q (μ := μ)).indicator hS
  have hmon : ∫ ω, S.indicator (fun _ => q) ω ∂μ ≤ ∫ ω, g ω ∂μ := by
    apply integral_mono_ae hi hg
    filter_upwards [h, hgn] with ω h₁ h₂
    by_cases hω : ω ∈ S
    · simpa [hω] using h₁ hω
    · simpa [hω] using h₂
  simpa [integral_indicator hS, setIntegral_const, smul_eq_mul, mul_comm] using hmon


end KendallHarmonicLocal
