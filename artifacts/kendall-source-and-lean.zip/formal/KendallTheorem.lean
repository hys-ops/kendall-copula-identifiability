import KendallProfileRows
import KendallRigidityConclusion
import KendallScale

/-! In any finite dimension d ≥ 2, the Williamson--Kendall law determines
the positive reciprocal-radius quantile up to scale and the copula on the closed cube. -/
noncomputable section
open Set MeasureTheory
namespace KendallTheorem

/-- Equality of the two population laws gives a single positive scale, without
a hypothesis about the smoothness of either distribution or its support. -/
theorem proportional_of_kendall_law (D E : KendallRank.Quantile) (m : ℕ) (hm : 0 < m)
    (hlaw : KendallRank.kendallLaw D m = KendallRank.kendallLaw E m) :
    ∃ c > 0, ∀ p ∈ Ioo (0:ℝ) 1, E.x p = c * D.x p := by
  have R := KendallProfileRows.rows D E m hm hlaw
  obtain ⟨a, ha⟩ := KendallMeasureRigidity.constant R
  exact KendallScale.proportional D.pos E.pos ⟨a,ha⟩

/-- The shortfall integrals at all interior ranks determine the quantile up to scale. -/
theorem rank_profile_eq_iff (D E : KendallRank.Quantile) (m : ℕ) (hm : 0 < m) :
    (∀ p ∈ Ioo (0 : ℝ) 1,
      (∫ s in Ioo (0 : ℝ) p, (1 - D.x s / D.x p) ^ m) =
      (∫ s in Ioo (0 : ℝ) p, (1 - E.x s / E.x p) ^ m)) ↔
    ∃ c > 0, ∀ p ∈ Ioo (0 : ℝ) 1, E.x p = c * D.x p := by
  constructor
  · intro heq
    apply proportional_of_kendall_law D E m hm
    unfold KendallRank.kendallLaw
    rw [Measure.map_map (KendallRank.measurable_score D m) D.measurable,
        Measure.map_map (KendallRank.measurable_score E m) E.measurable]
    apply Measure.map_congr
    apply (ae_restrict_iff' measurableSet_Ioo).2
    filter_upwards with p hp
    change KendallRank.score D m (D.x p) = KendallRank.score E m (E.x p)
    rw [KendallRank.score_rank_restrict D m hm.ne' hp,
        KendallRank.score_rank_restrict E m hm.ne' hp, heq p hp]
  · rintro ⟨c, hc, hscale⟩ p hp
    apply setIntegral_congr_fun measurableSet_Ioo
    intro s hs
    have hs' : s ∈ Ioo (0 : ℝ) 1 := ⟨hs.1, hs.2.trans hp.2⟩
    change (1 - D.x s / D.x p) ^ m = (1 - E.x s / E.x p) ^ m
    rw [hscale s hs', hscale p hp, mul_div_mul_left _ _ hc.ne']

/-- Identification of the Archimedean copula on the entire closed cube from
its population Kendall law, in the classical Williamson rank representation. -/
theorem identifies {d : ℕ} (hd : 2 ≤ d) (D E : KendallRank.Quantile)
    {φ₁ φ₂ : ℝ → ℝ} {C₁ C₂ : (Fin d → ℝ) → ℝ}
    (h₁ : KendallScale.Represents d C₁ (KendallScale.generator (d-1) D.x) φ₁)
    (h₂ : KendallScale.Represents d C₂ (KendallScale.generator (d-1) E.x) φ₂)
    (hlaw : KendallRank.kendallLaw D (d-1) = KendallRank.kendallLaw E (d-1)) :
    EqOn C₁ C₂ (KendallScale.cube d) := by
  obtain ⟨c,hc,hscale⟩ := proportional_of_kendall_law D E (d-1) (by omega) hlaw
  exact KendallScale.copula_eq_of_proportional h₁ h₂ hc hscale

end KendallTheorem
#print axioms KendallTheorem.proportional_of_kendall_law
#print axioms KendallTheorem.identifies
