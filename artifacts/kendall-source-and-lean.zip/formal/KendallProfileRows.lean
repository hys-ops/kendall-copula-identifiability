import KendallProjective
import KendallRank
import KendallMeasureRigidity

/-! All analytic and measure hypotheses of the rigidity theorem, for two
actual Williamson rank profiles of the same population Kendall law. -/
noncomputable section

open Set MeasureTheory Filter KendallRank KendallProjective KendallMeasureRigidity

namespace KendallProfileRows

private theorem interior {p s : ℝ} (hp : p ∈ rank) (hs : s ∈ rankPrefix p) : s ∈ rank :=
  ⟨hs.1, hs.2.trans hp.2⟩

private theorem localData (D E : Quantile) {p s : ℝ} (hp : p ∈ rank) (hs : s ∈ rankPrefix p) :
    0 < D.x s ∧ 0 < E.x s ∧ D.x s ≤ D.x p ∧ E.x s ≤ E.x p :=
  ⟨D.pos s (interior hp hs), E.pos s (interior hp hs),
    D.mono (interior hp hs) hp hs.2.le, E.mono (interior hp hs) hp hs.2.le⟩

theorem prefix_finite (D E : Quantile) {p : ℝ} (hp : p ∈ rank) :
    weightedMeasure volume D.x E.x (rankPrefix p) ≠ ⊤ := by
  rw [weightedMeasure, withDensity_apply _ measurableSet_Ioo]
  apply ne_of_lt
  calc
    _ ≤ ∫⁻ _ in rankPrefix p, ENNReal.ofReal (D.x p+E.x p) :=
      setLIntegral_mono' measurableSet_Ioo (fun s hs =>
        ENNReal.ofReal_le_ofReal (add_le_add (localData D E hp hs).2.2.1
          (localData D E hp hs).2.2.2))
    _ < ⊤ := by
      rw [setLIntegral_const, Real.volume_Ioo]
      exact ENNReal.mul_lt_top ENNReal.ofReal_lt_top ENNReal.ofReal_lt_top

theorem prefix_positive (D E : Quantile) {p : ℝ} (hp : p ∈ rank) :
    0 < (weightedMeasure volume D.x E.x).real (rankPrefix p) := by
  apply ENNReal.toReal_pos _ (prefix_finite D E hp)
  rw [weightedMeasure, withDensity_apply _ measurableSet_Ioo]
  apply ne_of_gt
  apply (lintegral_pos_iff_support (f := fun s => ENNReal.ofReal (D.x s + E.x s))
    (D.measurable.add E.measurable).ennreal_ofReal).2
  have hsub : rankPrefix p ⊆ Function.support (fun s => ENNReal.ofReal (D.x s + E.x s)) := by
    intro s hs
    exact (ENNReal.ofReal_pos.mpr (add_pos (D.pos s (interior hp hs)) (E.pos s (interior hp hs)))).ne'
  apply lt_of_lt_of_le _ (measure_mono (μ := volume.restrict (rankPrefix p)) hsub)
  rw [Measure.restrict_apply measurableSet_Ioo, inter_self, Real.volume_Ioo, sub_zero]
  exact ENNReal.ofReal_pos.mpr hp.1

theorem rows (D E : Quantile) (m : ℕ) (hm : 0 < m)
    (hlaw : kendallLaw D m = kendallLaw E m) :
    Rows (weightedMeasure volume D.x E.x) (z D.x E.x) (H m D.x E.x) m := by
  let μ := weightedMeasure volume D.x E.x
  have hpres (p : ℝ) (hp : p ∈ rank) : IsFiniteMeasure (μ.restrict (rankPrefix p)) :=
    isFiniteMeasure_restrict.mpr (prefix_finite D E hp)
  have hb (p : ℝ) (hp : p ∈ rank) (s : ℝ) (hs : s ∈ rankPrefix p) :
      H m D.x E.x p s ∈ Icc (0:ℝ) m := by
    obtain ⟨hx,hy,hx',hy'⟩ := localData D E hp hs
    exact H_mem hx hy hx' hy'
  have hzb (s : ℝ) (hs : s ∈ rank) : z D.x E.x s ∈ Icc (0:ℝ) 1 :=
    z_mem (D.pos s hs) (E.pos s hs)
  refine ⟨by exact_mod_cast hm, z_measurable D.measurable E.measurable, hzb,
    fun _ hp => prefix_finite D E hp, fun _ hp => prefix_positive D E hp, hb, ?_, ?_, ?_, ?_⟩
  · intro γ hγ
    refine ⟨γ^(m-1), pow_pos hγ _, ?_⟩
    intro p hp s hs hh
    obtain ⟨hx,hy,hx',hy'⟩ := localData D E hp hs
    rw [abs_sub_comm] at hh
    exact (pow_le_pow_left₀ hγ.le hh _).trans (gap_weight hm hx hy hx' hy')
  · intro p hp
    let _ := hpres p hp
    apply (integrable_const (μ := μ.restrict (rankPrefix p)) (m:ℝ)).mono'
    · exact (H_measurable D.measurable E.measurable p).aestronglyMeasurable
    · filter_upwards [ae_restrict_mem (μ := μ) measurableSet_Ioo] with s hs
      change ‖H m D.x E.x p s‖ ≤ (m:ℝ)
      exact (Real.norm_of_nonneg (hb p hp s hs).1).trans_le (hb p hp s hs).2
  · intro p hp
    let _ := hpres p hp
    apply (integrable_const (μ := μ.restrict (rankPrefix p)) (m:ℝ)).mono'
    · exact ((z_measurable D.measurable E.measurable).mul
        (H_measurable D.measurable E.measurable p)).aestronglyMeasurable
    · filter_upwards [ae_restrict_mem (μ := μ) measurableSet_Ioo] with s hs
      obtain ⟨hz,hz'⟩ := hzb s (interior hp hs)
      obtain ⟨hh,hh'⟩ := hb p hp s hs
      change ‖z D.x E.x s * H m D.x E.x p s‖ ≤ (m:ℝ)
      rw [Real.norm_of_nonneg (mul_nonneg hz hh)]
      exact (mul_le_of_le_one_left hh hz').trans hh'
  · intro p hp
    let _ : IsFiniteMeasure (volume.restrict (Ioo (0:ℝ) p)) :=
      isFiniteMeasure_restrict.mpr (by rw [Real.volume_Ioo]; exact ENNReal.ofReal_ne_top)
    exact harmonic_integral volume m D.x E.x p D.measurable E.measurable
      (D.pos p hp) (E.pos p hp) (fun _ hs => localData D E hp hs)
      (rank_moment_eq D E m hm.ne' hlaw hp)

end KendallProfileRows
#print axioms KendallProfileRows.rows
