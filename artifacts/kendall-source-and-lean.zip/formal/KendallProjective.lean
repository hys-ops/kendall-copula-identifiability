import KendallHarmonicLocal
import Mathlib.Algebra.Ring.GeomSum
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Measurability
import Mathlib.Tactic.NormNum

/-! Exact passage from the common Williamson rank profile to a harmonic
projective coordinate, against a single fixed reference measure. -/

noncomputable section
open Set MeasureTheory Filter

namespace KendallProjective

def z (x y : ℝ → ℝ) (p : ℝ) : ℝ := x p / (x p + y p)
def a (x : ℝ → ℝ) (p s : ℝ) : ℝ := 1 - x s / x p

def powerSum (m : ℕ) (A B : ℝ) : ℝ :=
  ∑ k ∈ Finset.range m, A^k * B^(m-1-k)

def H (m : ℕ) (x y : ℝ → ℝ) (p s : ℝ) : ℝ := powerSum m (a x p s) (a y p s)

def weightedMeasure (μ : Measure ℝ) (x y : ℝ → ℝ) : Measure ℝ :=
  μ.withDensity (fun s => ENNReal.ofReal (x s + y s))

theorem z_measurable {x y : ℝ → ℝ} (hx : Measurable x) (hy : Measurable y) :
    Measurable (z x y) := hx.div (hx.add hy)

theorem H_measurable {m : ℕ} {x y : ℝ → ℝ} (hx : Measurable x) (hy : Measurable y) (p : ℝ) :
    Measurable (H m x y p) := by
  unfold H powerSum a
  fun_prop

theorem z_mem {x y : ℝ → ℝ} {s : ℝ} (hx : 0 < x s) (hy : 0 < y s) :
    z x y s ∈ Icc (0:ℝ) 1 := by
  exact ⟨div_nonneg hx.le (add_pos hx hy).le, (div_le_one (add_pos hx hy)).mpr (by linarith)⟩

private theorem a_mem {x : ℝ → ℝ} {p s : ℝ} (h : 0 < x s) (hle : x s ≤ x p) :
    a x p s ∈ Icc (0:ℝ) 1 := by
  have hp := h.trans_le hle
  exact ⟨sub_nonneg.mpr ((div_le_one hp).mpr hle), sub_le_self _ (div_nonneg h.le hp.le)⟩

theorem H_mem {m : ℕ} {x y : ℝ → ℝ} {p s : ℝ}
    (hxs : 0 < x s) (hys : 0 < y s) (hxp : x s ≤ x p) (hyp : y s ≤ y p) :
    H m x y p s ∈ Icc (0:ℝ) m := by
  have hA := a_mem hxs hxp
  have hB := a_mem hys hyp
  unfold H powerSum
  constructor
  · exact Finset.sum_nonneg (fun i _ => mul_nonneg (pow_nonneg hA.1 i) (pow_nonneg hB.1 (m-1-i)))
  · calc
      _ ≤ ∑ _ ∈ Finset.range m, (1:ℝ) := by
        apply Finset.sum_le_sum
        intro i _
        exact (mul_le_of_le_one_right (pow_nonneg hA.1 i) (pow_le_one₀ hB.1 hB.2)).trans
          (pow_le_one₀ hA.1 hA.2)
      _ = m := by simp

theorem gap_weight {m : ℕ} (hm : 0 < m) {x y : ℝ → ℝ} {p s : ℝ}
    (hxs : 0 < x s) (hys : 0 < y s) (hxp : x s ≤ x p) (hyp : y s ≤ y p) :
    |z x y s - z x y p|^(m-1) ≤ H m x y p s := by
  have hA := a_mem hxs hxp
  have hB := a_mem hys hyp
  have hs : |z x y s - z x y p| ≤ max (a x p s) (a y p s) :=
    KendallHarmonicLocal.coordinate_separation hxs hys hxp hyp
  have hp := pow_le_pow_left₀ (abs_nonneg _) hs (m-1)
  have hn (i : ℕ) (_ : i ∈ Finset.range m) :
      0 ≤ (a x p s)^i * (a y p s)^(m-1-i) :=
    mul_nonneg (pow_nonneg hA.1 i) (pow_nonneg hB.1 _)
  rw [H, powerSum]
  rcases le_total (a x p s) (a y p s) with h | h
  · rw [max_eq_right h] at hp
    exact hp.trans (by simpa using Finset.single_le_sum hn (Finset.mem_range.mpr hm : 0 ∈ Finset.range m))
  · rw [max_eq_left h] at hp
    have hi : m-1 ∈ Finset.range m := Finset.mem_range.mpr (by omega)
    exact hp.trans (by simpa using Finset.single_le_sum hn hi)

theorem harmonic_identity {m : ℕ} {x y : ℝ → ℝ} {p s : ℝ}
    (hxs : 0 < x s) (hys : 0 < y s) (hxp : 0 < x p) (hyp : 0 < y p) :
    (x s+y s) * ((z x y p-z x y s)*H m x y p s) =
      (x p * y p / (x p+y p)) * ((a x p s)^m - (a y p s)^m) := by
  rw [← geom_sum₂_mul]
  unfold z H powerSum a
  have hs := (add_pos hxs hys).ne'
  have hp := (add_pos hxp hyp).ne'
  field_simp [hxp.ne', hyp.ne', hs, hp]
  ring

/-- A single arbitrary base measure can be used for all rows.  It suffices that
the present prefix is finite.  In probability ranks the base measure is volume. -/
theorem harmonic_integral (μ : Measure ℝ) (m : ℕ) (x y : ℝ → ℝ)
    (p : ℝ) [IsFiniteMeasure (μ.restrict (Ioo (0:ℝ) p))]
    (hx : Measurable x) (hy : Measurable y) (hxp : 0 < x p) (hyp : 0 < y p)
    (hxy : ∀ s ∈ Ioo (0:ℝ) p, 0 < x s ∧ 0 < y s ∧ x s ≤ x p ∧ y s ≤ y p)
    (rank_eq : (∫ s in Ioo (0:ℝ) p, (a x p s)^m ∂μ) =
      ∫ s in Ioo (0:ℝ) p, (a y p s)^m ∂μ) :
    (∫ s in Ioo (0:ℝ) p, (z x y p - z x y s)*H m x y p s ∂(weightedMeasure μ x y)) = 0 := by
  have hi {f : ℝ → ℝ} (hf : Measurable f)
    (hp : ∀ s ∈ Ioo (0:ℝ) p, 0 < f s ∧ f s ≤ f p) :
      IntegrableOn (fun s => (a f p s)^m) (Ioo (0:ℝ) p) μ := by
    apply (integrable_const (μ := μ.restrict (Ioo (0:ℝ) p)) (1:ℝ)).mono'
    · exact ((measurable_const.sub (hf.div_const _)).pow_const m).aestronglyMeasurable
    · filter_upwards [ae_restrict_mem (μ := μ) measurableSet_Ioo] with s hs
      obtain ⟨h₁,h₂⟩ := hp s hs
      have ha := a_mem h₁ h₂
      simpa only [Real.norm_eq_abs, abs_of_nonneg (pow_nonneg ha.1 m)] using
        (pow_le_one₀ ha.1 ha.2 : (a f p s)^m ≤ 1)
  have hiX := hi hx (fun s hs => ⟨(hxy s hs).1, (hxy s hs).2.2.1⟩)
  have hiY := hi hy (fun s hs => ⟨(hxy s hs).2.1, (hxy s hs).2.2.2⟩)
  unfold weightedMeasure
  rw [setIntegral_withDensity_eq_setIntegral_toReal_smul₀
    (f := fun s => ENNReal.ofReal (x s+y s))
    (s := Ioo (0:ℝ) p) (μ := μ)
    ((hx.add hy).ennreal_ofReal.aemeasurable) (ae_of_all _ fun _ => ENNReal.ofReal_lt_top) _
    measurableSet_Ioo]
  calc
    _ = ∫ s in Ioo (0:ℝ) p, (x p * y p / (x p+y p)) *
        ((a x p s)^m-(a y p s)^m) ∂μ := by
      apply setIntegral_congr_fun measurableSet_Ioo
      intro s hs
      obtain ⟨h₁,h₂,_,_⟩ := hxy s hs
      dsimp only
      rw [ENNReal.toReal_ofReal (add_pos h₁ h₂).le, smul_eq_mul]
      exact harmonic_identity h₁ h₂ hxp hyp
    _ = 0 := by rw [integral_const_mul, integral_sub hiX hiY, rank_eq, sub_self, mul_zero]

end KendallProjective
#print axioms KendallProjective.harmonic_integral
#print axioms KendallProjective.gap_weight
