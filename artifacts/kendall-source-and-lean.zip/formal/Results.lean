import KendallSample

#print axioms KendallRank.rank_moment_eq
#print axioms KendallRank.quantileOfMeasure_map
#print axioms KendallRank.radial_rank_moment_eq
#print axioms KendallProjective.harmonic_integral
#print axioms KendallProjective.gap_weight
#print axioms KendallCut.high_row
#print axioms KendallCut.low_row
#print axioms KendallMeasureRigidity.constant
#print axioms KendallTheorem.proportional_of_kendall_law
#print axioms KendallTheorem.rank_profile_eq_iff
#print axioms KendallPopulation.identifies
#print axioms KendallSample.population_law
#print axioms KendallSample.identifies
