import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.Tactic.FunProp
import Mathlib.Topology.Order.LeftRightNhds
import Mathlib.Tactic.Linarith

/-! Rank representation on the open unit interval, allowing atoms in the radial law. -/
noncomputable section
open MeasureTheory Set Filter
namespace KendallRank

/-- Uniform rank law (endpoints have zero Lebesgue mass). -/
def uniform : Measure ℝ := volume.restrict (Ioo 0 1)

/-- Increasing rank scores of equal law interlace at every pair of interior ranks. -/
theorem le_of_lt_of_map_eq {f g : ℝ → ℝ} (hf : Measurable f) (hg : Measurable g)
    (mf : MonotoneOn f (Ioo 0 1)) (mg : MonotoneOn g (Ioo 0 1))
    (hlaw : uniform.map f = uniform.map g) {p q : ℝ} (hp : 0 < p)
    (hpq : p < q) (hq : q < 1) : f p ≤ g q := by
  by_contra! h
  have hs : MeasurableSet (Iic (g q)) := measurableSet_Iic
  have he := congrArg (fun (μ : Measure ℝ) => μ (Iic (g q))) hlaw
  change (uniform.map f) (Iic (g q)) = (uniform.map g) (Iic (g q)) at he
  rw [Measure.map_apply hf hs, Measure.map_apply hg hs, uniform,
      Measure.restrict_apply (hf hs), Measure.restrict_apply (hg hs)] at he
  have hgsub : Ioo 0 q ⊆ g ⁻¹' Iic (g q) ∩ Ioo 0 1 := by
    intro t ht
    have ht' : t ∈ Ioo (0:ℝ) 1 := ⟨ht.1, ht.2.trans hq⟩
    exact ⟨mg ht' ⟨hp.trans hpq,hq⟩ ht.2.le, ht'⟩
  have hfsub : f ⁻¹' Iic (g q) ∩ Ioo 0 1 ⊆ Ioo 0 p := by
    intro t ht
    refine ⟨ht.2.1, ?_⟩
    by_contra! hc
    exact (not_le_of_gt h) ((mf ⟨hp,hpq.trans hq⟩ ht.2 hc).trans ht.1)
  have a := (measure_mono (μ := volume) hgsub).trans (he.ge.trans (measure_mono hfsub))
  rw [Real.volume_Ioo, Real.volume_Ioo, sub_zero, sub_zero] at a
  exact (not_le_of_gt hpq) ((ENNReal.ofReal_le_ofReal_iff hp.le).mp a)

/-- The left-continuous increasing representative of a uniform-rank law is unique
at every interior point. -/
theorem rank_eq_of_map_eq {f g : ℝ → ℝ} (hf : Measurable f) (hg : Measurable g)
    (mf : MonotoneOn f (Ioo 0 1)) (mg : MonotoneOn g (Ioo 0 1))
    (cf : ∀ p ∈ Ioo (0 : ℝ) 1, ContinuousWithinAt f (Iio p) p)
    (cg : ∀ p ∈ Ioo (0 : ℝ) 1, ContinuousWithinAt g (Iio p) p)
    (hlaw : uniform.map f = uniform.map g) :
    EqOn f g (Ioo 0 1) := by
  intro p hp
  apply le_antisymm
  · apply le_of_tendsto (cf p hp)
    filter_upwards [Ioo_mem_nhdsLT hp.1] with q hq
    exact le_of_lt_of_map_eq hf hg mf mg hlaw hq.1 hq.2 hp.2
  · apply le_of_tendsto (cg p hp)
    filter_upwards [Ioo_mem_nhdsLT hp.1] with q hq
    exact le_of_lt_of_map_eq hg hf mg mf hlaw.symm hq.1 hq.2 hp.2


instance : IsFiniteMeasure uniform where
  measure_univ_lt_top := by simp [uniform, Real.volume_Ioo]

/-- A distribution presented by the left-continuous quantile of its positive reciprocal radius. -/
structure Quantile where
  x : ℝ → ℝ
  measurable : Measurable x
  mono : MonotoneOn x (Ioo 0 1)
  pos : ∀ p ∈ Ioo (0 : ℝ) 1, 0 < x p
  leftContinuous : ∀ p ∈ Ioo (0 : ℝ) 1, ContinuousWithinAt x (Iio p) p

attribute [fun_prop] Quantile.measurable

/-- Williamson score at the radius reciprocal t, calculated using the quantile law. -/
def score (D : Quantile) (m : ℕ) (t : ℝ) : ℝ :=
  ∫ q, max (1 - D.x q / t) 0 ^ m ∂uniform

theorem score_as_radial_integral (D : Quantile) (m : ℕ) (t : ℝ) :
    score D m t = ∫ z, max (1 - z / t) 0 ^ m ∂(uniform.map D.x) := by
  symm
  apply integral_map_of_stronglyMeasurable D.measurable
  fun_prop

theorem measurable_score (D : Quantile) (m : ℕ) : Measurable (score D m) := by
  have hm : Measurable (fun (w : ℝ × ℝ) => max (1 - D.x w.2 / w.1) 0 ^ m) := by
    fun_prop (disch := exact D.measurable)
  exact hm.stronglyMeasurable.integral_prod_right'.measurable

private theorem ae_pos (D : Quantile) : ∀ᵐ q ∂uniform, 0 < D.x q := by
  apply (ae_restrict_iff' measurableSet_Ioo).2
  exact .of_forall D.pos

private theorem score_bound {a t : ℝ} (ha : 0 ≤ a) (ht : 0 < t) (m : ℕ) :
    ‖max (1 - a / t) 0 ^ m‖ ≤ 1 := by
  rw [Real.norm_eq_abs, abs_of_nonneg (pow_nonneg (le_max_right ..) m)]
  exact pow_le_one₀ (le_max_right ..)
    (max_le (sub_le_self _ (div_nonneg ha ht.le)) zero_le_one)

theorem continuousAt_score (D : Quantile) (m : ℕ) {t : ℝ} (ht : 0 < t) :
    ContinuousAt (score D m) t := by
  apply continuousAt_of_dominated (bound := fun _ => (1:ℝ))
  · exact .of_forall fun y => by
      have hm : Measurable (fun q => max (1 - D.x q / y) 0 ^ m) := by
        fun_prop (disch := exact D.measurable)
      exact hm.aestronglyMeasurable
  · filter_upwards [lt_mem_nhds ht] with y hy
    filter_upwards [ae_pos D] with q hq using score_bound hq.le hy m
  · exact integrable_const _
  · exact .of_forall fun q => by fun_prop (disch := exact ht.ne')

theorem monotoneOn_score (D : Quantile) (m : ℕ) : MonotoneOn (score D m) (Ioi 0) := by
  intro s hs t ht hst
  have hi {y : ℝ} (hy : 0 < y) : Integrable (fun q => max (1 - D.x q / y) 0 ^ m) uniform := by
    apply (integrable_const (1:ℝ)).mono'
    · have hm : Measurable (fun q => max (1 - D.x q / y) 0 ^ m) := by
        fun_prop (disch := exact D.measurable)
      exact hm.aestronglyMeasurable
    · filter_upwards [ae_pos D] with q hq using score_bound hq.le hy m
  apply integral_mono_ae (hi hs) (hi ht)
  filter_upwards [ae_pos D] with q hq
  exact pow_le_pow_left₀ (le_max_right ..)
    (max_le_max_right _ (sub_le_sub_left (div_le_div_of_nonneg_left hq.le hs hst) _)) m

/-- The population Kendall law in the Williamson representation, evaluated on the
same reciprocal radial law that generated the score. -/
def kendallLaw (D : Quantile) (m : ℕ) : Measure ℝ :=
  (uniform.map D.x).map (score D m)

/-- A common population law forces matching Williamson rank scores pointwise. -/
theorem score_rank_eq (D E : Quantile) (m : ℕ) (h : kendallLaw D m = kendallLaw E m) :
    EqOn (score D m ∘ D.x) (score E m ∘ E.x) (Ioo 0 1) := by
  have hmono (A : Quantile) : MonotoneOn (score A m ∘ A.x) (Ioo 0 1) :=
    (monotoneOn_score A m).comp A.mono A.pos
  have hleft (A : Quantile) (p : ℝ) (hp : p ∈ Ioo (0:ℝ) 1) :
      ContinuousWithinAt (score A m ∘ A.x) (Iio p) p :=
    (continuousAt_score A m (A.pos p hp)).comp_continuousWithinAt (A.leftContinuous p hp)
  apply rank_eq_of_map_eq ((measurable_score D m).comp D.measurable)
    ((measurable_score E m).comp E.measurable) (hmono D) (hmono E) (hleft D) (hleft E)
  simpa [kendallLaw, Measure.map_map (measurable_score D m) D.measurable,
    Measure.map_map (measurable_score E m) E.measurable] using h


/-- The positive part drops out below rank p; every higher rank and every tie
contributes zero for m positive. -/
theorem score_rank_restrict (D : Quantile) (m : ℕ) (hm : m ≠ 0) {p : ℝ}
    (hp : p ∈ Ioo (0:ℝ) 1) :
    score D m (D.x p) = ∫ q in Ioo 0 p, (1 - D.x q / D.x p) ^ m := by
  have hsub : Ioo (0:ℝ) p ∩ Ioo 0 1 = Ioo 0 p := by
    apply inter_eq_left.mpr
    exact Ioo_subset_Ioo_right hp.2.le
  have hcut : ∫ q, (Ioo (0:ℝ) p).indicator (fun q => (1 - D.x q / D.x p)^m) q ∂uniform
      = ∫ q in Ioo 0 p, (1 - D.x q / D.x p)^m := by
    rw [integral_indicator measurableSet_Ioo, uniform, Measure.restrict_restrict measurableSet_Ioo, hsub]
  apply Eq.trans _ hcut
  apply integral_congr_ae
  apply (ae_restrict_iff' measurableSet_Ioo).mpr
  filter_upwards with q hq
  by_cases h : q < p
  · have hqp : q ∈ Ioo (0:ℝ) p := ⟨hq.1,h⟩
    have hd : D.x q / D.x p ≤ 1 := (div_le_one (D.pos p hp)).mpr (D.mono hq hp h.le)
    simp [hqp, max_eq_left (sub_nonneg.mpr hd)]
  · have hqp : q ∉ Ioo (0:ℝ) p := fun hh => h hh.2
    have hd : 1 ≤ D.x q / D.x p :=
      (one_le_div (D.pos p hp)).mpr (D.mono hp hq (le_of_not_gt h))
    simp [hqp, max_eq_right (sub_nonpos.mpr hd), hm]

/-- The exact unrestricted-rank moment identity feeding the comparison proof. -/
theorem rank_moment_eq (D E : Quantile) (m : ℕ) (hm : m ≠ 0) (h : kendallLaw D m = kendallLaw E m)
    {p : ℝ} (hp : p ∈ Ioo (0:ℝ) 1) :
    (∫ q in Ioo 0 p, (1 - D.x q / D.x p)^m) =
    ∫ q in Ioo 0 p, (1 - E.x q / E.x p)^m := by
  rw [← score_rank_restrict D m hm hp, ← score_rank_restrict E m hm hp]
  exact score_rank_eq D E m h hp

end KendallRank
#print axioms KendallRank.score_rank_eq

#print axioms KendallRank.rank_moment_eq
