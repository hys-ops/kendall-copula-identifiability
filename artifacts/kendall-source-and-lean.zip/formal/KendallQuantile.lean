import KendallRank
import Mathlib.Probability.CDF

/-! Generalized inverse and its uniform-rank representation for arbitrary positive real laws. -/
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory
open scoped Topology
namespace KendallRank

/-- The infimum convention gives the left-continuous quantile. Outside the open
rank interval it is extended by zero to obtain a real-valued measurable function. -/
def inverseCDF (μ : Measure ℝ) (p : ℝ) : ℝ :=
  if p ∈ Ioo (0:ℝ) 1 then sInf {t | p ≤ cdf μ t} else 0

private theorem threshold_nonempty (μ : Measure ℝ) {p : ℝ} (hp : p < 1) :
    ({t | p ≤ cdf μ t} : Set ℝ).Nonempty := by
  obtain ⟨t,ht⟩ := ((tendsto_cdf_atTop μ).eventually (lt_mem_nhds hp)).exists
  exact ⟨t,ht.le⟩

private theorem threshold_bdd (μ : Measure ℝ) {p : ℝ} (hp : 0 < p) :
    BddBelow {t | p ≤ cdf μ t} := by
  obtain ⟨b,hb⟩ := ((tendsto_cdf_atBot μ).eventually (gt_mem_nhds hp)).exists
  refine ⟨b, fun t ht => ?_⟩
  exact le_of_not_gt fun h => (not_le_of_gt hb) (ht.trans ((monotone_cdf μ) h.le))

theorem inverseCDF_le_iff (μ : Measure ℝ) {p : ℝ} (hp : p ∈ Ioo (0:ℝ) 1) (t : ℝ) :
    inverseCDF μ p ≤ t ↔ p ≤ cdf μ t := by
  simp only [inverseCDF, hp, ↓reduceIte]
  constructor
  · intro h
    rw [← (cdf μ).iInf_Ioi_eq t]
    apply le_ciInf
    intro y
    have hlt : sInf {r | p ≤ cdf μ r} < (y:ℝ) := h.trans_lt y.2
    obtain ⟨z,hz,hzy⟩ := (csInf_lt_iff (threshold_bdd μ hp.1) (threshold_nonempty μ hp.2)).mp hlt
    exact hz.trans ((monotone_cdf μ) hzy.le)
  · exact csInf_le (threshold_bdd μ hp.1)

theorem inverseCDF_mono (μ : Measure ℝ) : MonotoneOn (inverseCDF μ) (Ioo 0 1) := by
  intro p hp q hq hpq
  exact (inverseCDF_le_iff μ hp _).2 (hpq.trans ((inverseCDF_le_iff μ hq _).1 le_rfl))

theorem inverseCDF_left (μ : Measure ℝ) {p : ℝ} (hp : p ∈ Ioo (0:ℝ) 1) :
    ContinuousWithinAt (inverseCDF μ) (Iio p) p := by
  apply tendsto_order.mpr
  constructor
  · intro a ha
    have hf : cdf μ a < p := lt_of_not_ge (fun h => ha.not_ge ((inverseCDF_le_iff μ hp a).mpr h))
    filter_upwards [Ioo_mem_nhdsLT hp.1, Ioo_mem_nhdsLT hf] with q hq hq'
    apply lt_of_not_ge
    intro h
    exact hq'.1.not_ge ((inverseCDF_le_iff μ ⟨hq.1, hq.2.trans hp.2⟩ a).mp h)
  · intro b hb
    filter_upwards [Ioo_mem_nhdsLT hp.1] with q hq
    exact ((inverseCDF_mono μ) ⟨hq.1,hq.2.trans hp.2⟩ hp hq.2.le).trans_lt hb

theorem measurable_inverseCDF (μ : Measure ℝ) : Measurable (inverseCDF μ) := by
  apply measurable_of_Iic
  intro t
  have h : inverseCDF μ ⁻¹' Iic t = (Ioo 0 1 ∩ Iic (cdf μ t)) ∪
      (if (0:ℝ) ≤ t then (Ioo 0 1)ᶜ else ∅) := by
    ext p
    by_cases hp : p ∈ Ioo (0:ℝ) 1
    · simp [hp, inverseCDF_le_iff μ hp]
    · simp [inverseCDF, hp]
  rw [h]
  apply (measurableSet_Ioo.inter measurableSet_Iic).union
  split_ifs <;> measurability

/-- The uniform image of the inverse CDF is the original law, including at atoms. -/
theorem inverseCDF_pushforward (μ : Measure ℝ) [IsProbabilityMeasure μ] :
    uniform.map (inverseCDF μ) = μ := by
  apply Measure.ext_of_Iic
  intro t
  rw [Measure.map_apply (measurable_inverseCDF μ) measurableSet_Iic,
    uniform, Measure.restrict_apply (measurable_inverseCDF μ measurableSet_Iic), ← ofReal_cdf μ t]
  have hs : Ioo 0 (cdf μ t) ⊆ inverseCDF μ ⁻¹' Iic t ∩ Ioo 0 1 := by
    intro p hp
    have hp' : p ∈ Ioo (0:ℝ) 1 := ⟨hp.1,hp.2.trans_le (cdf_le_one μ t)⟩
    exact ⟨(inverseCDF_le_iff μ hp' t).mpr hp.2.le, hp'⟩
  have ht : inverseCDF μ ⁻¹' Iic t ∩ Ioo 0 1 ⊆ Ioc 0 (cdf μ t) := by
    intro p hp
    exact ⟨hp.2.1, (inverseCDF_le_iff μ hp.2 t).mp hp.1⟩
  apply le_antisymm
  · simpa [Real.volume_Ioc] using (measure_mono (μ := volume) ht)
  · simpa [Real.volume_Ioo] using (measure_mono (μ := volume) hs)

/-- Every law supported on positive finite real reciprocals has the rank data used
by the identifiability argument. -/
def quantileOfMeasure (μ : Measure ℝ) [IsProbabilityMeasure μ] (h : μ (Iic 0) = 0) :
    Quantile where
  x := inverseCDF μ
  measurable := measurable_inverseCDF μ
  mono := inverseCDF_mono μ
  pos := by
    intro p hp
    apply lt_of_not_ge
    intro hz
    have he := (inverseCDF_le_iff μ hp 0).mp hz
    have hzero : cdf μ 0 = 0 := by simp [cdf_eq_real, measureReal_def, h]
    exact hp.1.not_ge (hzero ▸ he)
  leftContinuous := fun _ hp => inverseCDF_left μ hp

theorem quantileOfMeasure_map (μ : Measure ℝ) [IsProbabilityMeasure μ] (h : μ (Iic 0) = 0) :
    uniform.map (quantileOfMeasure μ h).x = μ := inverseCDF_pushforward μ


/-- The Williamson score of a reciprocal-radius law, without a rank presentation. -/
def radialScore (μ : Measure ℝ) (m : ℕ) (t : ℝ) : ℝ :=
  ∫ z, max (1 - z / t) 0 ^ m ∂μ

/-- The law of the Williamson score of a random reciprocal radius having law μ. -/
def radialKendallLaw (μ : Measure ℝ) (m : ℕ) : Measure ℝ :=
  μ.map (radialScore μ m)

theorem kendallLaw_quantileOfMeasure (μ : Measure ℝ) [IsProbabilityMeasure μ] (h : μ (Iic 0) = 0)
    (m : ℕ) : kendallLaw (quantileOfMeasure μ h) m = radialKendallLaw μ m := by
  have hs : score (quantileOfMeasure μ h) m = radialScore μ m := by
    funext t
    rw [score_as_radial_integral, quantileOfMeasure_map]
    rfl
  rw [kendallLaw, quantileOfMeasure_map, hs, radialKendallLaw]

/-- The prefix-moment identity for any two positive reciprocal-radius probability laws. -/
theorem radial_rank_moment_eq (μ ν : Measure ℝ) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    (hμ : μ (Iic 0) = 0) (hν : ν (Iic 0) = 0)
    (m : ℕ) (hm : m ≠ 0) (h : radialKendallLaw μ m = radialKendallLaw ν m)
    {p : ℝ} (hp : p ∈ Ioo (0:ℝ) 1) :
    (∫ q in Ioo 0 p, (1 - inverseCDF μ q / inverseCDF μ p)^m) =
    ∫ q in Ioo 0 p, (1 - inverseCDF ν q / inverseCDF ν p)^m := by
  apply rank_moment_eq (quantileOfMeasure μ hμ) (quantileOfMeasure ν hν) m hm _ hp
  simpa only [kendallLaw_quantileOfMeasure] using h

end KendallRank
#print axioms KendallRank.quantileOfMeasure_map

#print axioms KendallRank.radial_rank_moment_eq
