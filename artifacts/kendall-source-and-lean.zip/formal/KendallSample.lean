import KendallPopulation
import Mathlib.MeasureTheory.Measure.AEMeasurable

/-! Direct link to the usual population Kendall law, the law of C(U) under a
copula sample U. The classical Williamson input is precisely that the generator
is the radial integral for the law of the reciprocal sum of the generator inverses. -/
noncomputable section
open Set MeasureTheory
namespace KendallSample

/-- Reciprocal Archimedean radius of a point in the interior of the cube. -/
def reciprocalRadius {Ω : Type*} {d : ℕ} (φ : ℝ → ℝ) (U : Ω → Fin d → ℝ) (ω : Ω) : ℝ :=
  (∑ i, φ (U ω i))⁻¹

/-- A random sample with the indicated reciprocal-radius distribution.
For samples with uniform marginals, the interior condition holds almost surely. -/
structure RadialSample {Ω : Type*} [MeasurableSpace Ω] {d : ℕ} (P : Measure Ω)
    (U : Ω → Fin d → ℝ) (φ : ℝ → ℝ) (μ : Measure ℝ) : Prop where
  interior : ∀ᵐ ω ∂P, U ω ∈ KendallScale.interiorCube d
  measurableRadius : AEMeasurable (reciprocalRadius φ U) P
  radiusLaw : P.map (reciprocalRadius φ U) = μ

theorem score_at_inv (μ : Measure ℝ) (m : ℕ) (s : ℝ) :
    KendallRank.radialScore μ m s⁻¹ = KendallPopulation.generator μ m s := by
  simp [KendallRank.radialScore, KendallPopulation.generator, div_eq_mul_inv, mul_comm]

theorem measurable_radialScore (μ : Measure ℝ) [IsProbabilityMeasure μ] (m : ℕ) :
    Measurable (KendallRank.radialScore μ m) := by
  have hf : Measurable (fun (w : ℝ × ℝ) => max (1 - w.2 / w.1) 0 ^ m) := by fun_prop
  exact hf.stronglyMeasurable.integral_prod_right'.measurable

/-- Evaluating the copula at the sample gives exactly the Williamson score of
its reciprocal radius, in distribution, with no continuity of the radial law. -/
theorem population_law {d : ℕ} {Ω : Type*} [MeasurableSpace Ω] (P : Measure Ω)
    (U : Ω → Fin d → ℝ) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    {φ : ℝ → ℝ} {C : (Fin d → ℝ) → ℝ}
    (rep : KendallScale.Represents d C (KendallPopulation.generator μ (d-1)) φ)
    (sample : RadialSample P U φ μ) :
    P.map (C ∘ U) = KendallRank.radialKendallLaw μ (d-1) := by
  have hae : C ∘ U =ᵐ[P] KendallRank.radialScore μ (d-1) ∘ reciprocalRadius φ U := by
    filter_upwards [sample.interior] with ω hω
    change C (U ω) = KendallRank.radialScore μ (d-1) (∑ i, φ (U ω i))⁻¹
    rw [score_at_inv]
    exact rep.interior _ hω
  calc
    _ = P.map (KendallRank.radialScore μ (d-1) ∘ reciprocalRadius φ U) := Measure.map_congr hae
    _ = (P.map (reciprocalRadius φ U)).map (KendallRank.radialScore μ (d-1)) :=
      (AEMeasurable.map_map_of_aemeasurable (measurable_radialScore μ _).aemeasurable sample.measurableRadius).symm
    _ = _ := by rw [sample.radiusLaw]; rfl

theorem positive_support {d : ℕ} (hd : 0 < d) {Ω : Type*} [MeasurableSpace Ω]
    (P : Measure Ω) (U : Ω → Fin d → ℝ) (μ : Measure ℝ)
    {C : (Fin d → ℝ) → ℝ} {ψ φ : ℝ → ℝ}
    (rep : KendallScale.Represents d C ψ φ) (sample : RadialSample P U φ μ) :
    μ (Iic 0) = 0 := by
  rw [← sample.radiusLaw, Measure.map_apply_of_aemeasurable sample.measurableRadius measurableSet_Iic]
  rw [measure_eq_zero_iff_ae_notMem]
  filter_upwards [sample.interior] with ω hω
  change ¬ (∑ i, φ (U ω i))⁻¹ ≤ 0
  apply not_le_of_gt
  apply inv_pos.mpr
  have hpos (i : Fin d) : 0 < φ (U ω i) := rep.positive _ (hω i (mem_univ i))
  exact Finset.sum_pos' (fun i _ => (hpos i).le) ⟨⟨0, hd⟩, Finset.mem_univ _, hpos _⟩

/-- Equal laws of the actual sample evaluations C₁(U₁) and C₂(U₂) identify both CDFs
on the closed unit cube, for arbitrary positive radial probability laws. -/
theorem identifies {d : ℕ} (hd : 2 ≤ d)
    {Ω₁ Ω₂ : Type*} [MeasurableSpace Ω₁] [MeasurableSpace Ω₂]
    (P₁ : Measure Ω₁) (P₂ : Measure Ω₂) (U₁ : Ω₁ → Fin d → ℝ) (U₂ : Ω₂ → Fin d → ℝ)
    (μ ν : Measure ℝ) [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {φ₁ φ₂ : ℝ → ℝ} {C₁ C₂ : (Fin d → ℝ) → ℝ}
    (rep₁ : KendallScale.Represents d C₁ (KendallPopulation.generator μ (d-1)) φ₁)
    (rep₂ : KendallScale.Represents d C₂ (KendallPopulation.generator ν (d-1)) φ₂)
    (sample₁ : RadialSample P₁ U₁ φ₁ μ) (sample₂ : RadialSample P₂ U₂ φ₂ ν)
    (hlaw : P₁.map (C₁ ∘ U₁) = P₂.map (C₂ ∘ U₂)) :
    EqOn C₁ C₂ (KendallScale.cube d) := by
  apply KendallPopulation.identifies hd μ ν
    (positive_support (by omega) P₁ U₁ μ rep₁ sample₁)
    (positive_support (by omega) P₂ U₂ ν rep₂ sample₂) rep₁ rep₂
  rwa [← population_law P₁ U₁ μ rep₁ sample₁, ← population_law P₂ U₂ ν rep₂ sample₂]

end KendallSample
#print axioms KendallSample.identifies
