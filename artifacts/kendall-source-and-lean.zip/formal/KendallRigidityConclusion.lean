import KendallMeasureRigidity
import KendallBudget

/-! Rigidity for rank-space past-directed integral equations. -/
noncomputable section
open Set MeasureTheory Filter
namespace KendallMeasureRigidity

theorem barrier_of_rows {μ z H B} (R : Rows μ z H B) {b : ℝ} (hb : b ∈ rank) :
    KendallRigidity.Barrier z b := by
  intro M δ hδ hdrop hM
  obtain ⟨α,hα,hsep⟩ := R.separated (δ/2) (half_pos hδ)
  obtain ⟨η,hη,hηδ,hbudget⟩ := KendallBudget.small_bad hδ hα R.Bpos
  refine ⟨η,hη,?_⟩
  intro a ha hpeak m hm0 hmb hmin
  have har : a ∈ rank := ⟨ha.1,ha.2.trans_lt hb.2⟩
  let T := rankPrefix a
  let bad := T ∩ {s | z s ≤ M-δ}
  let good := T \ bad
  have hbad : MeasurableSet bad := measurableSet_Ioo.inter (measurableSet_le R.measurable measurable_const)
  have hgood : MeasurableSet good := measurableSet_Ioo.diff hbad
  have hbt : bad ⊆ T := inter_subset_left
  have hgt : good ⊆ T := sdiff_subset
  have : IsFiniteMeasure (μ.restrict T) :=
    ⟨by rw [Measure.restrict_apply_univ]; exact (R.finite a har).lt_top⟩
  have hHi := KendallCut.high_row (μ:=μ.restrict T) (δ:=δ/2) (α:=α) hbad
    (R.hInt a har) (R.zhInt a har) (R.harmonic a har) (hM a ha)
    (half_pos hδ).le hα.le (B:=B) (by
      filter_upwards [ae_restrict_mem (μ:=μ) (show MeasurableSet T from measurableSet_Ioo)] with s hs
      exact ⟨(R.rowBound a har s hs).1,(R.rowBound a har s hs).2,hM s ⟨hs.1,hs.2.le.trans ha.2⟩⟩) (by
      filter_upwards with s hs
      have hzs : z s ≤ M-δ := hs.2
      exact ⟨by linarith,hsep a har s hs.1 (by
        calc δ/2 ≤ z a-z s := by linarith
             _ ≤ _ := le_abs_self _)⟩)
  rw [restrict_real hbad hbt,restrict_real_univ] at hHi
  have hsmall := hbudget (sub_nonneg.mpr (hM a ha)) hpeak (measureReal_nonneg)
    (R.positive a har) (by convert hHi using 1; ring)
  have hmass : μ.real T ≤ μ.real bad + μ.real good := by
    have he : T = bad ∪ good := by ext t; simp [good]; tauto
    nth_rw 1 [he]
    apply measureReal_union_le
  obtain ⟨ε,hε,hrep⟩ := KendallBudget.repel hδ hα R.Bpos (R.positive a har) (R.positive b hb)
  refine ⟨ε,hε,?_⟩
  intro q hq hlow
  have hqr : q ∈ rank := ⟨ha.1.trans_le hq.1,hq.2.trans_lt hb.2⟩
  have hTq : T ⊆ rankPrefix q := Ioo_subset_Ioo_right hq.1
  have : IsFiniteMeasure (μ.restrict (rankPrefix q)) :=
    ⟨by rw [Measure.restrict_apply_univ]; exact (R.finite q hqr).lt_top⟩
  have hLow := KendallCut.low_row (μ:=μ.restrict (rankPrefix q)) (δ:=δ) (α:=α)
    hgood hbad (R.hInt q hqr) (R.zhInt q hqr) (R.harmonic q hqr)
    (hmb.trans (R.bounded b hb).2) (hmin q hq) R.Bpos.le hα.le (by
      filter_upwards [ae_restrict_mem (μ:=μ) (show MeasurableSet (rankPrefix q) from measurableSet_Ioo)] with s hs
      exact ⟨(R.rowBound q hqr s hs).1,(R.rowBound q hqr s hs).2,(R.bounded s ⟨hs.1,hs.2.trans hqr.2⟩).1⟩) (by
      filter_upwards [ae_restrict_mem (μ:=μ) (show MeasurableSet (rankPrefix q) from measurableSet_Ioo)] with s hs hnb
      by_cases hsa : s < a
      · have hzs : M-δ < z s := lt_of_not_ge (fun h => hnb ⟨⟨hs.1,hsa⟩,h⟩)
        linarith
      · exact hmin s ⟨le_of_not_gt hsa,hs.2.le.trans hq.2⟩) (by
      filter_upwards with s hs
      have hzs : M-δ < z s := lt_of_not_ge (fun h => hs.2 ⟨hs.1,h⟩)
      refine ⟨by linarith,hsep q hqr s (hTq hs.1) ?_⟩
      rw [abs_sub_comm]
      calc δ/2 ≤ z s-z q := by linarith
           _ ≤ _ := le_abs_self _) hδ.le
  rw [restrict_real hgood (hgt.trans hTq),restrict_real hbad (hbt.trans hTq),restrict_real_univ] at hLow
  have hle : μ.real (rankPrefix q) ≤ μ.real (rankPrefix b) :=
    measureReal_mono (Ioo_subset_Ioo_right hq.2) (R.finite _ hb)
  have hresult := hrep hmass (sub_nonneg.mpr (hmin q hq)) hle hsmall hLow
  linarith

/-- Every bounded normalized profile with a uniformly separating harmonic
kernel on all earlier ranks is constant. Only local finiteness is required. -/
theorem constant {μ z H B} (R : Rows μ z H B) : ∃ c : ℝ, ∀ p ∈ rank, z p = c :=
  KendallRigidity.constant_of_barriers R.bounded (fun _ hb => barrier_of_rows R hb)
    (fun _ hb => barrier_of_rows R.reflect hb)

end KendallMeasureRigidity
#print axioms KendallMeasureRigidity.constant
