import KendallHarmonicLocal

/-! A near-maximum row localizes the reference measure; a later minimum
forces the complementary mass to control the localized mass. -/
noncomputable section
open MeasureTheory Set Filter
namespace KendallCut
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsFiniteMeasure μ]

omit [IsFiniteMeasure μ] in
private theorem row_eq {z h : Ω → ℝ} (hi : Integrable h μ)
    (hz : Integrable (fun s => z s*h s) μ) (a : ℝ) :
    (∫ s, (a-z s)*h s ∂μ) = a*(∫ s, h s ∂μ) - ∫ s, z s*h s ∂μ := by
  simp_rw [sub_mul]
  rw [integral_sub (hi.const_mul a) hz, integral_const_mul]

theorem high_row {z h : Ω → ℝ} {M z₀ δ α B : ℝ} {bad : Set Ω}
    (hbad : MeasurableSet bad) (hi : Integrable h μ)
    (hz : Integrable (fun s => z s*h s) μ)
    (harm : (∫ s, (z₀-z s)*h s ∂μ) = 0)
    (hz₀ : z₀ ≤ M) (_hd : 0 ≤ δ) (ha : 0 ≤ α)
    (hBounds : ∀ᵐ s ∂μ, 0 ≤ h s ∧ h s ≤ B ∧ z s ≤ M)
    (hsep : ∀ᵐ s ∂μ, s ∈ bad → z s ≤ M-2*δ ∧ α ≤ h s) :
    (2*δ*α)*μ.real bad ≤ (M-z₀)*B*μ.real univ := by
  have hfun : (fun s => (M-z s)*h s) = fun s => M*h s-z s*h s := by
    funext s; ring
  have hint : Integrable (fun s => (M-z s)*h s) μ := hfun ▸ (hi.const_mul M).sub hz
  have hlocal : (2*δ*α)*μ.real bad ≤ ∫ s, (M-z s)*h s ∂μ := by
    apply KendallHarmonicLocal.mass_control hbad hint
    · filter_upwards [hBounds] with s hs using mul_nonneg (sub_nonneg.mpr hs.2.2) hs.1
    · filter_upwards [hsep, hBounds] with s hs hh hmem
      obtain ⟨h₁,h₂⟩ := hs hmem
      exact mul_le_mul (by linarith) h₂ ha (by linarith [hh.2.2])
  have hI : ∫ s, h s ∂μ ≤ B*μ.real univ := by
    have hh := integral_mono_ae hi (integrable_const B) (hBounds.mono fun _ h => h.2.1)
    simpa [integral_const, smul_eq_mul, mul_comm] using hh
  rw [row_eq hi hz z₀] at harm
  rw [row_eq hi hz M] at hlocal
  calc
    _ ≤ (M-z₀)*(∫ s, h s ∂μ) := by nlinarith [hlocal]
    _ ≤ (M-z₀)*(B*μ.real univ) := mul_le_mul_of_nonneg_left hI (sub_nonneg.mpr hz₀)
    _ = _ := by ring

theorem low_row {z h : Ω → ℝ} {m z₀ δ α B : ℝ} {good bad : Set Ω}
    (hgood : MeasurableSet good) (hbad : MeasurableSet bad)
    (hi : Integrable h μ) (hz : Integrable (fun s => z s*h s) μ)
    (harm : (∫ s, (z₀-z s)*h s ∂μ) = 0)
    (hm : m ≤ 1) (hmz : m ≤ z₀) (hB : 0 ≤ B) (ha : 0 ≤ α)
    (hBounds : ∀ᵐ s ∂μ, 0 ≤ h s ∧ h s ≤ B ∧ 0 ≤ z s)
    (hOut : ∀ᵐ s ∂μ, s ∉ bad → m ≤ z s)
    (hsep : ∀ᵐ s ∂μ, s ∈ good → m+δ ≤ z s ∧ α ≤ h s) (hd : 0 ≤ δ) :
    (δ*α)*μ.real good ≤ B*μ.real bad + (z₀-m)*B*μ.real univ := by
  let I : Ω → ℝ := bad.indicator fun _ => B
  let f : Ω → ℝ := fun s => z s*h s - m*h s + I s
  have hiI : Integrable I μ := (integrable_const B).indicator hbad
  have hif : Integrable f μ := (hz.sub (hi.const_mul m)).add hiI
  have hIn : ∀ s, 0 ≤ I s := by
    intro s
    by_cases hs : s ∈ bad <;> simp [I, hs, hB]
  have hloc : (δ*α)*μ.real good ≤ ∫ s, f s ∂μ := by
    apply KendallHarmonicLocal.mass_control hgood hif
    · filter_upwards [hBounds,hOut] with s hb hx
      change 0 ≤ z s*h s - m*h s + I s
      by_cases hs : s ∈ bad
      · simp [I, hs]
        nlinarith [mul_nonneg (show 0 ≤ z s - m + 1 by linarith [hb.2.2]) hb.1, hb.2.1]
      · have := hx hs
        nlinarith [mul_nonneg (sub_nonneg.mpr this) hb.1, hIn s]
    · filter_upwards [hsep,hBounds] with s hs hb hmem
      obtain ⟨hx, hh⟩ := hs hmem
      change δ*α ≤ z s*h s - m*h s + I s
      have := mul_le_mul (show δ ≤ z s-m by linarith) hh ha (by linarith : 0 ≤ z s-m)
      nlinarith [hIn s]
  have hiIeq : ∫ s, I s ∂μ = B*μ.real bad := by
    simp [I, integral_indicator hbad, smul_eq_mul, mul_comm]
  have hI : (∫ s, h s ∂μ) ≤ B*μ.real univ := by
    have hh := integral_mono_ae hi (integrable_const B) (hBounds.mono fun _ h => h.2.1)
    simpa [integral_const, smul_eq_mul, mul_comm] using hh
  have hmul := mul_le_mul_of_nonneg_left hI (sub_nonneg.mpr hmz)
  rw [row_eq hi hz z₀] at harm
  change _ ≤ ∫ s, z s*h s-m*h s+I s ∂μ at hloc
  have hrs : Integrable (fun s => z s*h s-m*h s) μ := hz.sub (hi.const_mul m)
  rw [integral_add hrs hiI, integral_sub hz (hi.const_mul m),
     integral_const_mul, hiIeq] at hloc
  nlinarith

end KendallCut
#print axioms KendallCut.high_row
#print axioms KendallCut.low_row
