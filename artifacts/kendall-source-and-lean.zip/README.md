# Kendall distributions identify Archimedean copulas in every finite dimension

This is the anonymous manuscript and its Lean supplement, 24 November 2026. The main theorem is stated for each finite integer dimension d ≥ 2. The TeX source contains the full mathematical argument.

## Reading the formal proof

| Manuscript statement | Where to look in formal/ |
| --- | --- |
| Reciprocal radius of an interior sample, its score law | KendallSample.lean, `KendallSample.population_law` |
| Lower quantile and uniform pushforward, rank identity in the presence of atoms | KendallQuantile.lean and KendallRank.lean, including `KendallRank.radial_rank_moment_eq` |
| Difference of powers and lower bound for separated values | KendallProjective.lean, `KendallProjective.harmonic_integral` and `KendallProjective.gap_weight` |
| Concentration below a high value and contradiction at a later low value | KendallCut.lean and KendallRigidityConclusion.lean, culminating in `KendallMeasureRigidity.constant` |
| Equality of the rank profiles if and only if the quantiles are proportional (Theorem 3) | KendallTheorem.lean, `KendallTheorem.rank_profile_eq_iff` |
| Generator scaling and identification on the closed unit cube (Theorem 1) | KendallScale.lean, KendallPopulation.lean and `KendallSample.identifies` in KendallSample.lean |

The endpoint takes equality of the pushforward laws of C₁(U₁) and C₂(U₂) as its comparison hypothesis. On each side, KendallScale.Represents supplies the Archimedean formula, continuity of C on the closed cube and its generator's inverse identities on levels in (0,1). KendallSample.RadialSample supplies an almost surely interior sample and specifies the measurable reciprocal radius and its law. The generator in the final signature is the Williamson integral for that law. The published radial representation theorem of McNeil and Nešlehová and the uniform marginal property supply these inputs for an Archimedean copula. The statistical applications in Section 5 follow from published results and are outside the Lean development.

## Reproduce the verification

Use a standard installation of elan, Git and Python 3. From the directory containing this README run

```sh
cd formal
lake exe cache get
lake env python3 verify.py --kernel
```

The included lean-toolchain selects Lean 4.34.1. The lakefile and lake-manifest.json pin mathlib at d13f23b723b8a846827a245b89c10fc7d3f11612 and the manifest records the transitive revisions. A first run downloads dependencies and compiled mathlib artifacts. Keep the distributed manifest in place to reproduce the dependency versions.

An existing build of the same mathlib revision can also be used. Put the pinned distribution's lean and leanchecker executables on PATH, then run the following from formal/.

```sh
python3 verify.py --mathlib /path/to/built/mathlib --kernel
```

In this mode, the caller supplies the matching dependency build. The script checks the Lean version, compiles every local module in a fresh directory with warnings treated as errors, audits the declarations in Results.lean, and replays the resulting modules with leanchecker. The full output is in formal/verification.log.

## Typeset the paper and check the files

With a current TeX Live installation, run these commands in the directory containing this README.

```sh
pdflatex -interaction=nonstopmode -halt-on-error Kendall_Identification.tex
pdflatex -interaction=nonstopmode -halt-on-error Kendall_Identification.tex
sha256sum -c SHA256SUMS
```

The checksum list covers the supplied manuscript source, this README, all Lean source and configuration files, the verification script and its run log.
